var hal__atomic_8c =
[
    [ "DRIVER_VERSION", "hal__atomic_8c.html#ae578001fe043b4cca7a0edd801cfe9c4", null ],
    [ "atomic_enter_critical", "group__doc__driver__hal__helper__atomic.html#ga3bd20e6e0bdec53177758490510ba916", null ],
    [ "atomic_get_version", "group__doc__driver__hal__helper__atomic.html#ga75fe13100e2799eb24a80123bc8c3787", null ],
    [ "atomic_leave_critical", "group__doc__driver__hal__helper__atomic.html#gaef0ccaa2438aca5ea074b36252d65990", null ]
];