var group__doc__driver__hal__helper__init =
[
    [ "init_get_version", "group__doc__driver__hal__helper__init.html#ga7f3a0a79c14d4043ea30435f561af05f", null ]
];