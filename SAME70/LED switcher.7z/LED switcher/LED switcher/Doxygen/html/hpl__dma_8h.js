var hpl__dma_8h =
[
    [ "_dma_callback_type", "group___h_p_l.html#gaf65002742527ebb1bf4157229990d465", [
      [ "DMA_TRANSFER_COMPLETE_CB", "group___h_p_l.html#ggaf65002742527ebb1bf4157229990d465a19b079989919f03c4255df0f79904ac1", null ],
      [ "DMA_TRANSFER_ERROR_CB", "group___h_p_l.html#ggaf65002742527ebb1bf4157229990d465a3812bd4059d9aa1cffd2960b231c1799", null ]
    ] ],
    [ "_dma_dstinc_enable", "group___h_p_l.html#ga73e591a3b8a4aa4cb5dce0ffd93a59d9", null ],
    [ "_dma_enable_transaction", "group___h_p_l.html#ga274dfd4667fa2dedb9d550b4f92189d8", null ],
    [ "_dma_get_channel_resource", "group___h_p_l.html#ga651aecc566b4d05e988791c85e2efa99", null ],
    [ "_dma_init", "group___h_p_l.html#ga80907744cae62409ce0764e1d2ade4a6", null ],
    [ "_dma_set_data_amount", "group___h_p_l.html#gac6ccb282c608691f7cb8ec2350677fbf", null ],
    [ "_dma_set_destination_address", "group___h_p_l.html#ga2a40fb892a927cef99863e1f4ca71f85", null ],
    [ "_dma_set_irq_state", "group___h_p_l.html#ga2b1a1a06af556aa36746d0aada5c6525", null ],
    [ "_dma_set_next_descriptor", "group___h_p_l.html#ga5a21a8bed0c621818406fa02c3112d72", null ],
    [ "_dma_set_source_address", "group___h_p_l.html#gae86b412fa86727c686496e63dac65a52", null ],
    [ "_dma_srcinc_enable", "group___h_p_l.html#ga72844b40ebb8b4d69ec49a218389a9e3", null ]
];