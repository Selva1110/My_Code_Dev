var hal__io_8c =
[
    [ "DRIVER_VERSION", "hal__io_8c.html#ae578001fe043b4cca7a0edd801cfe9c4", null ],
    [ "io_get_version", "hal__io_8c.html#a081053bb07051453fcafb199d9ff4504", null ],
    [ "io_read", "group__doc__driver__hal__helper__io.html#gaf5e8722129933fa8e014144fd7505be6", null ],
    [ "io_write", "group__doc__driver__hal__helper__io.html#ga81aac60d5ce6feb0c44f8937d7c02f14", null ]
];