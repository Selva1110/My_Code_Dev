var structlist__descriptor =
[
    [ "head", "structlist__descriptor.html#acc7a3bb5c92dc985a2a7c27c958f1ed8", null ]
];