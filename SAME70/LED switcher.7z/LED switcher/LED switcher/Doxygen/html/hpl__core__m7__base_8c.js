var hpl__core__m7__base_8c =
[
    [ "CONF_HCLK_FREQUENCY", "hpl__core__m7__base_8c.html#a199055a220946feb5efe8e7cba7eeff3", null ],
    [ "HCLK_FREQ_POWER", "hpl__core__m7__base_8c.html#aa5ac539930ed8b156f424f3ad6ae4cfa", null ],
    [ "_get_cycles_for_ms", "group___h_p_l.html#gabf15f09c56b3ef75a3dbf7073092c51f", null ],
    [ "_get_cycles_for_us", "group___h_p_l.html#gacdb903e26206a1b890c9465e20455aef", null ],
    [ "_get_reset_reason", "group___h_p_l.html#gab7e1d30a2aa0a64c175ce3ce373b3c4f", null ],
    [ "_irq_clear", "group___h_p_l.html#ga80f1b1a044a8773e23b38517296620b4", null ],
    [ "_irq_disable", "group___h_p_l.html#gae6a80cff8a450795dc3f2d6df1a19464", null ],
    [ "_irq_enable", "group___h_p_l.html#gac8b7aa49ad81aecd34603b4dc23dd143", null ],
    [ "_irq_get_current", "group___h_p_l.html#ga082e8d19d78ab2cf2f63ded8530c7852", null ],
    [ "_irq_register", "group___h_p_l.html#ga1ee85f2f8227e335c654b9085e9b7d5c", null ],
    [ "_irq_set", "group___h_p_l.html#ga7720726f19dfdda1561a042483c97a58", null ],
    [ "_reset_mcu", "group___h_p_l.html#gaf1c17c7797e22fd860d303deda80e17c", null ],
    [ "Default_Handler", "hpl__core__m7__base_8c.html#a4e0c522c1bb26af24accaf20e6b87d12", null ],
    [ "_irq_table", "hpl__core__m7__base_8c.html#a7f41f9238e734e44845a3dc9c71d62d2", null ]
];