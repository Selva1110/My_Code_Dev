var annotated_dup =
[
    [ "_dma_callbacks", "struct__dma__callbacks.html", "struct__dma__callbacks" ],
    [ "_dma_resource", "struct__dma__resource.html", "struct__dma__resource" ],
    [ "_irq_descriptor", "struct__irq__descriptor.html", "struct__irq__descriptor" ],
    [ "event", "structevent.html", "structevent" ],
    [ "io_descriptor", "structio__descriptor.html", "structio__descriptor" ],
    [ "list_descriptor", "structlist__descriptor.html", "structlist__descriptor" ],
    [ "list_element", "structlist__element.html", "structlist__element" ]
];