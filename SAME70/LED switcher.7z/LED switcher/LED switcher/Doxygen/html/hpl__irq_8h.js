var hpl__irq_8h =
[
    [ "_irq_clear", "group___h_p_l.html#ga80f1b1a044a8773e23b38517296620b4", null ],
    [ "_irq_disable", "group___h_p_l.html#gae6a80cff8a450795dc3f2d6df1a19464", null ],
    [ "_irq_enable", "group___h_p_l.html#gac8b7aa49ad81aecd34603b4dc23dd143", null ],
    [ "_irq_get_current", "group___h_p_l.html#ga082e8d19d78ab2cf2f63ded8530c7852", null ],
    [ "_irq_register", "group___h_p_l.html#ga1ee85f2f8227e335c654b9085e9b7d5c", null ],
    [ "_irq_set", "group___h_p_l.html#ga7720726f19dfdda1561a042483c97a58", null ]
];