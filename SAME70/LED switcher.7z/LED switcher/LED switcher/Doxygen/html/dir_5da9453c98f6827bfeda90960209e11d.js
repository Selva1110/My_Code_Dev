var dir_5da9453c98f6827bfeda90960209e11d =
[
    [ "hpl_pmc.c", "hpl__pmc_8c.html", "hpl__pmc_8c" ],
    [ "hpl_pmc.h", "hpl__pmc_8h.html", "hpl__pmc_8h" ],
    [ "hpl_sleep.c", "hpl__sleep_8c.html", "hpl__sleep_8c" ]
];