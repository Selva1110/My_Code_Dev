var structlist__element =
[
    [ "next", "structlist__element.html#a66e1becb179745b2a4070941b9a4052d", null ]
];