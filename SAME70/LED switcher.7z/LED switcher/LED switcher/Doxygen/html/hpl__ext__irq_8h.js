var hpl__ext__irq_8h =
[
    [ "_ext_irq_deinit", "group___h_p_l.html#gad29f685cb658b260303c55fb7a88cdb0", null ],
    [ "_ext_irq_enable", "group___h_p_l.html#gac2fa4b43da6356425b0188b744b6f4cc", null ],
    [ "_ext_irq_init", "group___h_p_l.html#gad7c12a758c9839e074d1d97d255e09ab", null ]
];