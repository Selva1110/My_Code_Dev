var startup__same70q21b_8c =
[
    [ "__libc_init_array", "startup__same70q21b_8c.html#a5f388c8556f7cb6a84b5692db6b6ad80", null ],
    [ "Dummy_Handler", "startup__same70q21b_8c.html#a4ed9b32000d3b15c46ffd748f32ed44d", null ],
    [ "NonMaskableInt_Handler", "startup__same70q21b_8c.html#aebf4fdba7e93193caf0d78b18a87f7c2", null ],
    [ "Reset_Handler", "startup__same70q21b_8c.html#ae7ee340978f5c25f52f0cad1457c6616", null ],
    [ "_efixed", "startup__same70q21b_8c.html#aa55487a2e05bbec386ff62a79418827e", null ],
    [ "_erelocate", "startup__same70q21b_8c.html#a59f8a39545ac1b9b88d4228c40c910b9", null ],
    [ "_estack", "startup__same70q21b_8c.html#a69247aef56f755ef3b08265060dea50f", null ],
    [ "_etext", "startup__same70q21b_8c.html#abba93927cdaa2d32967cfc724f47cf8f", null ],
    [ "_ezero", "startup__same70q21b_8c.html#ad4c54e57daaa1859c4fd4208ed7d31fa", null ],
    [ "_sfixed", "startup__same70q21b_8c.html#a797d7617293913aabf29979f9355c069", null ],
    [ "_srelocate", "startup__same70q21b_8c.html#ac50d147d186c5fcf7efa97a4197e530e", null ],
    [ "_sstack", "startup__same70q21b_8c.html#ae588877090aec0bc36ee7c0ecf084ed4", null ],
    [ "_szero", "startup__same70q21b_8c.html#a5c6ed4fbf19b32595d4afb2c25aa8363", null ]
];