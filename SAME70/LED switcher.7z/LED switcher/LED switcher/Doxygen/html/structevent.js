var structevent =
[
    [ "cb", "structevent.html#a0dfaf0bb56fc7c24f2c7b23d08a0744e", null ],
    [ "elem", "structevent.html#a63bde48c922403f20d4607f0cf207755", null ],
    [ "mask", "structevent.html#a0424e81216afd94115c0c24198f106b4", null ]
];