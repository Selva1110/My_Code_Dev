var dir_f5396a40e9aa2f3894e64b71e105f519 =
[
    [ "hpl_core_m7_base.c", "hpl__core__m7__base_8c.html", "hpl__core__m7__base_8c" ],
    [ "hpl_core_port.h", "hpl__core__port_8h.html", null ],
    [ "hpl_init.c", "hpl__init_8c.html", "hpl__init_8c" ]
];