var hal__gpio_8h =
[
    [ "gpio_get_version", "hal__gpio_8h.html#a19c3104daa7a427258fc4d1ba26db13b", null ]
];