var group__doc__driver__hal__utils__macro =
[
    [ "ARRAY_SIZE", "group__doc__driver__hal__utils__macro.html#ga25f003de16c08a4888b69f619d70f427", null ],
    [ "clz", "group__doc__driver__hal__utils__macro.html#ga004f88903a09b9c23017e697eaf5a845", null ],
    [ "COMPILER_PACK_RESET", "group__doc__driver__hal__utils__macro.html#ga38d28b622a4bc7b0f3fb2be2ef1e0086", null ],
    [ "COMPILER_PACK_SET", "group__doc__driver__hal__utils__macro.html#gae2c02ff865ca6538b4b1bddbf2a6876c", null ],
    [ "COMPILER_PRAGMA", "group__doc__driver__hal__utils__macro.html#ga85a3ab5701281268521f109ed0078668", null ],
    [ "CONTAINER_OF", "group__doc__driver__hal__utils__macro.html#gae5f8e0a04e100a3953e38a3c7bdbc4f4", null ],
    [ "ctz", "group__doc__driver__hal__utils__macro.html#gab069bfec305db5213465d3b689836404", null ],
    [ "LE_2_U16", "group__doc__driver__hal__utils__macro.html#ga28c4c688462eddbe0385bdece51c5f33", null ],
    [ "LE_2_U32", "group__doc__driver__hal__utils__macro.html#gac21ac7b0f38e7b8138886c362d9cc663", null ],
    [ "LE_BYTE0", "group__doc__driver__hal__utils__macro.html#gaab4d1853098bbbfe4567d6cd7f2c099a", null ],
    [ "LE_BYTE1", "group__doc__driver__hal__utils__macro.html#ga2c2cccafec8ecf0d26a8bdcf8f7748d3", null ],
    [ "LE_BYTE2", "group__doc__driver__hal__utils__macro.html#gac21be76d243d97c095fe4ec85c94968c", null ],
    [ "LE_BYTE3", "group__doc__driver__hal__utils__macro.html#ga3ef5f564d5325745d309b92ca5be0462", null ],
    [ "max", "group__doc__driver__hal__utils__macro.html#gac39d9cef6a5e030ba8d9e11121054268", null ],
    [ "min", "group__doc__driver__hal__utils__macro.html#gabb702d8b501669a23aa0ab3b281b9384", null ],
    [ "pos_of_mask", "group__doc__driver__hal__utils__macro.html#ga6e6ec9c159cae4680d073d707063fa0e", null ],
    [ "round_up", "group__doc__driver__hal__utils__macro.html#gab4181d52c8a5083a8f30e3063893f3da", null ],
    [ "size_of_mask", "group__doc__driver__hal__utils__macro.html#gacb24f277663a5c87482fbcdbef5f2bd2", null ],
    [ "FUNC_PTR", "group__doc__driver__hal__utils__macro.html#gae40b38bc5f5a5bd452bdd59c67d9a9cf", null ]
];