var dir_27b0c362890f8e55b465fd5279fa526b =
[
    [ "core", "dir_7fc74f912756259783ab3764be5ad86a.html", "dir_7fc74f912756259783ab3764be5ad86a" ],
    [ "pmc", "dir_2a854008c4705bc91c17f9e89a09aed8.html", "dir_2a854008c4705bc91c17f9e89a09aed8" ],
    [ "systick", "dir_9ca6a57fa4d2f69903ec0f9cc769c7a5.html", "dir_9ca6a57fa4d2f69903ec0f9cc769c7a5" ],
    [ "xdmac", "dir_e994728929194cce2fc97f0dee353950.html", "dir_e994728929194cce2fc97f0dee353950" ]
];