var struct__dma__callbacks =
[
    [ "error", "group___h_p_l.html#gaad4da2e79be4a592b1cddfd24b4a37b2", null ],
    [ "transfer_done", "group___h_p_l.html#gac208a67b3bcd677808f8e933b14cfc2b", null ]
];