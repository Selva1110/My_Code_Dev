var dir_2a854008c4705bc91c17f9e89a09aed8 =
[
    [ "hpl_pmc.d", "hpl__pmc_8d.html", null ],
    [ "hpl_sleep.d", "hpl__sleep_8d.html", null ]
];