var peripheral__clk__config_8h =
[
    [ "CONF_CPU_FREQUENCY", "peripheral__clk__config_8h.html#a68b93cb1c373be54c2b7cee881ca869a", null ],
    [ "CONF_FCLK_FREQUENCY", "peripheral__clk__config_8h.html#ac92214a398cec454554f373e8cc906b1", null ],
    [ "CONF_HCLK_FREQUENCY", "peripheral__clk__config_8h.html#a199055a220946feb5efe8e7cba7eeff3", null ],
    [ "CONF_MCK_FREQUENCY", "peripheral__clk__config_8h.html#a6a9a80e65d97a7ecd0dd53b0fd8741b6", null ],
    [ "CONF_PCK6_FREQUENCY", "peripheral__clk__config_8h.html#aa81200e6e489aa0c2394304b0a899f70", null ],
    [ "CONF_SLCK_FREQUENCY", "peripheral__clk__config_8h.html#a86cdccbf028cfe48ecd2057c42f83079", null ]
];