var group__doc__driver__hal__delay =
[
    [ "delay_get_version", "group__doc__driver__hal__delay.html#gabb8969af264a11a3360634635244eca4", null ],
    [ "delay_init", "group__doc__driver__hal__delay.html#ga8f6bf53e286cef2eb222e9432a230836", null ],
    [ "delay_ms", "group__doc__driver__hal__delay.html#gad2dd6e794004b50917d231195c324ce5", null ],
    [ "delay_us", "group__doc__driver__hal__delay.html#gaa17c6e82a9085391c696904957505621", null ]
];