var group__doc__driver__hal__helper__io =
[
    [ "io_descriptor", "structio__descriptor.html", [
      [ "read", "structio__descriptor.html#a8ad97905c11dc07cd30373afc0fc146f", null ],
      [ "write", "structio__descriptor.html#a962235264b6c73e3ab712acb64022194", null ]
    ] ],
    [ "io_read_t", "group__doc__driver__hal__helper__io.html#ga4d9ae58de2887289fe09eac6f0aa8be7", null ],
    [ "io_write_t", "group__doc__driver__hal__helper__io.html#gacb03c48993a6786f00946c196c40add1", null ],
    [ "io_read", "group__doc__driver__hal__helper__io.html#gaf5e8722129933fa8e014144fd7505be6", null ],
    [ "io_write", "group__doc__driver__hal__helper__io.html#ga81aac60d5ce6feb0c44f8937d7c02f14", null ]
];