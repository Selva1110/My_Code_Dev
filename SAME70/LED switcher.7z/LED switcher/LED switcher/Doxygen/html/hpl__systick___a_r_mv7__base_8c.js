var hpl__systick___a_r_mv7__base_8c =
[
    [ "_delay_cycles", "group___h_p_l.html#gaa9e7b0c5bb246838e100046abf186bb8", null ],
    [ "_delay_init", "group___h_p_l.html#ga4689ea1d17db0a91e3db670687bfe640", null ],
    [ "_system_time_deinit", "group___h_p_l.html#ga7bd979fd9280b6f1d630f2afa36aa3e5", null ],
    [ "_system_time_get", "group___h_p_l.html#gaef21251348cfac8ea881d7927a678fc7", null ],
    [ "_system_time_get_max_time_value", "group___h_p_l.html#gac4972d67e3648ca8a51181ce8fc6e616", null ],
    [ "_system_time_init", "group___h_p_l.html#gafa42a76bae0892be69f99fad9ad2f312", null ]
];