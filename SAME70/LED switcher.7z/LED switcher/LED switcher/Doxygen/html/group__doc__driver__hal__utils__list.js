var group__doc__driver__hal__utils__list =
[
    [ "list_element", "structlist__element.html", [
      [ "next", "structlist__element.html#a66e1becb179745b2a4070941b9a4052d", null ]
    ] ],
    [ "list_descriptor", "structlist__descriptor.html", [
      [ "head", "structlist__descriptor.html#acc7a3bb5c92dc985a2a7c27c958f1ed8", null ]
    ] ],
    [ "is_list_element", "group__doc__driver__hal__utils__list.html#ga26022c1362f0fa7e17b734262229c1a7", null ],
    [ "list_delete_element", "group__doc__driver__hal__utils__list.html#gad5a2a1ff5dcdfadb47d4ba436e154c98", null ],
    [ "list_insert_after", "group__doc__driver__hal__utils__list.html#ga55b8c083fa131f829b1c998e14352f34", null ],
    [ "list_insert_as_head", "group__doc__driver__hal__utils__list.html#gafb3237f00dbf55a40075f3a42c49d32a", null ],
    [ "list_insert_at_end", "group__doc__driver__hal__utils__list.html#ga48c5a1a13223944dd190a6a028075deb", null ],
    [ "list_remove_head", "group__doc__driver__hal__utils__list.html#ga2269db44f7013963f60c568dd8d08022", null ]
];