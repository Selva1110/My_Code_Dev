var hpl__reset_8h =
[
    [ "reset_reason", "group___h_p_l.html#ga9066b7b3f20c4514ad24dcbff8fa3898", [
      [ "RESET_TYPE_GENERAL", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898a94285cbf222b8b0e1388003119d4ae97", null ],
      [ "RESET_TYPE_BACKUP", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898af532bbd475834adf76f7cf66d54ba4f8", null ],
      [ "RESET_TYPE_WDT", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898a83472f71eadc272a57ad6e9bb37296f7", null ],
      [ "RESET_TYPE_SOFT", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898a1aef0ed301fefe5f3ac29842bf491ef1", null ],
      [ "RESET_TYPE_USER", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898a1a98b163b1f2d7f0a40357c16d2ba703", null ],
      [ "RESET_TYPE_CPU_FAIL", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898a10b1b6abd0a0636fa55b4419c43a07f8", null ],
      [ "RESET_TYPE_SLCK_XTA", "group___h_p_l.html#gga9066b7b3f20c4514ad24dcbff8fa3898aeb89ac2ce74c9489bf97567435e8decb", null ]
    ] ],
    [ "_get_reset_reason", "group___h_p_l.html#gab7e1d30a2aa0a64c175ce3ce373b3c4f", null ],
    [ "_reset_mcu", "group___h_p_l.html#gaf1c17c7797e22fd860d303deda80e17c", null ]
];