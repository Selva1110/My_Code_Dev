var hpl__time__measure_8h =
[
    [ "system_time_t", "group___h_p_l.html#ga5885ba48297c95f5c8a108cfa02e6e55", null ],
    [ "_system_time_deinit", "group___h_p_l.html#ga7bd979fd9280b6f1d630f2afa36aa3e5", null ],
    [ "_system_time_get", "group___h_p_l.html#gaef21251348cfac8ea881d7927a678fc7", null ],
    [ "_system_time_get_max_time_value", "group___h_p_l.html#gac4972d67e3648ca8a51181ce8fc6e616", null ],
    [ "_system_time_init", "group___h_p_l.html#gafa42a76bae0892be69f99fad9ad2f312", null ]
];