var modules =
[
    [ "Doc_driver_hal_helper_atomic", "group__doc__driver__hal__helper__atomic.html", "group__doc__driver__hal__helper__atomic" ],
    [ "Delay Driver", "group__doc__driver__hal__delay.html", "group__doc__driver__hal__delay" ],
    [ "Init Driver", "group__doc__driver__hal__helper__init.html", "group__doc__driver__hal__helper__init" ],
    [ "I/O Driver", "group__doc__driver__hal__helper__io.html", "group__doc__driver__hal__helper__io" ],
    [ "Doc_driver_hal_helper_sleep", "group__doc__driver__hal__helper__sleep.html", "group__doc__driver__hal__helper__sleep" ],
    [ "Core", "group___h_p_l.html", "group___h_p_l" ],
    [ "Doc_driver_hal_utils_macro", "group__doc__driver__hal__utils__macro.html", "group__doc__driver__hal__utils__macro" ],
    [ "Doc_driver_hal_utils_list", "group__doc__driver__hal__utils__list.html", "group__doc__driver__hal__utils__list" ]
];