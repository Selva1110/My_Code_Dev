var hal__atomic_8h =
[
    [ "CRITICAL_SECTION_ENTER", "group__doc__driver__hal__helper__atomic.html#ga039bfe712b6ba4388a35672f54763391", null ],
    [ "CRITICAL_SECTION_LEAVE", "group__doc__driver__hal__helper__atomic.html#ga6b32c9f95e7c6b604d621e215c514015", null ],
    [ "hal_atomic_t", "group__doc__driver__hal__helper__atomic.html#ga6b3a0c9eea25111ac1877e0302e2fe1c", null ],
    [ "atomic_enter_critical", "group__doc__driver__hal__helper__atomic.html#ga3bd20e6e0bdec53177758490510ba916", null ],
    [ "atomic_get_version", "group__doc__driver__hal__helper__atomic.html#ga75fe13100e2799eb24a80123bc8c3787", null ],
    [ "atomic_leave_critical", "group__doc__driver__hal__helper__atomic.html#gaef0ccaa2438aca5ea074b36252d65990", null ]
];