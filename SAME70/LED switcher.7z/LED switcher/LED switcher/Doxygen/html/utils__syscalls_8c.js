var utils__syscalls_8c =
[
    [ "_close", "utils__syscalls_8c.html#a5aab5e2acfd600e3667dc915a2bbc7cb", null ],
    [ "_exit", "utils__syscalls_8c.html#abc96bd69b58b2deaddb484478d911c1b", null ],
    [ "_fstat", "utils__syscalls_8c.html#a41eef54307912a82d20e71c3d47315aa", null ],
    [ "_getpid", "utils__syscalls_8c.html#a945e539df8e0f66d3c73c533fe1968ee", null ],
    [ "_isatty", "utils__syscalls_8c.html#ad3134a3dc296622b8d1c5456e481505b", null ],
    [ "_kill", "utils__syscalls_8c.html#a3ada001944b574974184d2377be0bec3", null ],
    [ "_lseek", "utils__syscalls_8c.html#a7a61311bdf1cb025fc07dc2bdae22ce4", null ],
    [ "_sbrk", "utils__syscalls_8c.html#aae54d7b9578ba1fc171ce6f30f4c68a3", null ],
    [ "link", "utils__syscalls_8c.html#aa1f9baeed1efaed3c37861c144b6845b", null ],
    [ "_end", "utils__syscalls_8c.html#abb406f6b7d63af84fda76dbcdbac66c5", null ],
    [ "errno", "utils__syscalls_8c.html#ad65a8842cc674e3ddf69355898c0ecbf", null ]
];