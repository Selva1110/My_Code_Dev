var dir_0794e62ff977495350f706aeefd6f554 =
[
    [ "startup_same70q21b.c", "startup__same70q21b_8c.html", "startup__same70q21b_8c" ],
    [ "system_same70q21b.c", "system__same70q21b_8c.html", "system__same70q21b_8c" ]
];