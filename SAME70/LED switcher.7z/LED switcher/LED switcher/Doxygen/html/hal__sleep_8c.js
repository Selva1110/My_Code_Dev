var hal__sleep_8c =
[
    [ "DRIVER_VERSION", "hal__sleep_8c.html#ae578001fe043b4cca7a0edd801cfe9c4", null ],
    [ "sleep", "group__doc__driver__hal__helper__sleep.html#gab004676b3011ffebede7c473a5cdfccc", null ],
    [ "sleep_get_version", "group__doc__driver__hal__helper__sleep.html#gaab8a7b5dfa992a33c63e63ed98e4b105", null ]
];