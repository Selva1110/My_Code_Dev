var struct__dma__resource =
[
    [ "back", "group___h_p_l.html#ga2bc48d682ddf3001d31bef997b51a2ea", null ],
    [ "dma_cb", "group___h_p_l.html#gaab9927c3b8cdb168642916bd3e984a83", null ]
];