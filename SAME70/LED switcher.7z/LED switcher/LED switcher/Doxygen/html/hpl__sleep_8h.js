var hpl__sleep_8h =
[
    [ "_go_to_sleep", "group___h_p_l.html#ga8977ae60a1c30b8c2216f8f2a9c59b5e", null ],
    [ "_reset_mcu", "group___h_p_l.html#gaf1c17c7797e22fd860d303deda80e17c", null ],
    [ "_set_sleep_mode", "group___h_p_l.html#ga3e27d1d2dd8b2515a6724be9b34388f1", null ]
];