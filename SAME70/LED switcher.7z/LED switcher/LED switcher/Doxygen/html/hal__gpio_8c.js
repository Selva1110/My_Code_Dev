var hal__gpio_8c =
[
    [ "DRIVER_VERSION", "hal__gpio_8c.html#ae578001fe043b4cca7a0edd801cfe9c4", null ],
    [ "gpio_get_version", "hal__gpio_8c.html#a19c3104daa7a427258fc4d1ba26db13b", null ]
];