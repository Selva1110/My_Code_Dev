var hpl__pmc_8h =
[
    [ "PLL_COUNT", "hpl__pmc_8h.html#ae317ae04a6e923f7c3934adc0b985a20", null ],
    [ "PMC_PCR_GCLKCSS", "hpl__pmc_8h.html#a42a4ae85ce36d266d782677bbf790792", null ],
    [ "PMC_PCR_GCLKCSS_Msk", "hpl__pmc_8h.html#a945101420e50720d643d0400782c7ed3", null ],
    [ "PMC_PCR_GCLKCSS_Pos", "hpl__pmc_8h.html#a3f4bccd1005f68d7f39ca620fc90788a", null ],
    [ "PMC_PCR_GCLKDIV", "hpl__pmc_8h.html#a852a56571cd2ec7b62116691f48f00dc", null ],
    [ "PMC_PCR_GCLKDIV_Msk", "hpl__pmc_8h.html#a211a2281eea72442cb2dd24bb97bb9c4", null ],
    [ "PMC_PCR_GCLKDIV_Pos", "hpl__pmc_8h.html#a7fde752605c7f5623a182f38ffe7fb6d", null ],
    [ "PMC_PCR_GCLKEN", "hpl__pmc_8h.html#a61cac22244228514aa9a6028cd9a7778", null ],
    [ "_pmc_init", "group___h_p_l.html#ga580e99e942064901ed0f02f5d8789c7a", null ]
];