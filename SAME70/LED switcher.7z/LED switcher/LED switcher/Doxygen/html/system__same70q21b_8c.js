var system__same70q21b_8c =
[
    [ "__SYSTEM_CLOCK", "system__same70q21b_8c.html#a16323f44d2b5b11ef3972f71339cbd39", null ],
    [ "SystemCoreClockUpdate", "system__same70q21b_8c.html#ae0c36a9591fe6e9c45ecb21a794f0f0f", null ],
    [ "SystemInit", "system__same70q21b_8c.html#a93f514700ccf00d08dbdcff7f1224eb2", null ],
    [ "SystemCoreClock", "system__same70q21b_8c.html#aa3cd3e43291e81e795d642b79b6088e6", null ]
];