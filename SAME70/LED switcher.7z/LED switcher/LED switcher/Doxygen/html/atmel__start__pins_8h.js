var atmel__start__pins_8h =
[
    [ "GPIO_PIN_FUNCTION_A", "atmel__start__pins_8h.html#ab5bd4c0cb71ac137de1ec6f444e26313", null ],
    [ "GPIO_PIN_FUNCTION_B", "atmel__start__pins_8h.html#a8fb3098bd8c1cd13e63e434f65a45ebf", null ],
    [ "GPIO_PIN_FUNCTION_C", "atmel__start__pins_8h.html#a0ecff3470439b66a96f3c059eefcbd0e", null ],
    [ "GPIO_PIN_FUNCTION_D", "atmel__start__pins_8h.html#a5da2c04dfada4b04a409501e6a869f2f", null ],
    [ "LED0", "atmel__start__pins_8h.html#ae8d5b4e7e2d9d21caaa4744d385d7cc7", null ],
    [ "SW0", "atmel__start__pins_8h.html#af63c5c5dc7e761850ce251d500ef6abc", null ]
];