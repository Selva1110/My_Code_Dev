var struct__irq__descriptor =
[
    [ "handler", "group___h_p_l.html#ga5c5645efb32460ff3105eff8e6206b91", null ],
    [ "parameter", "group___h_p_l.html#ga9c58c3f373aebb6b725b9b47def981fd", null ]
];