===========
LED Flasher
===========

This example toggles the on-board LED marked as LED0 every time the button SW0
is pressed.

Drivers
-------
* GPIO
* Delay
